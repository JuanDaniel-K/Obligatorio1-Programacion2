﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class ConsultasMedicas
    {
        #region Atributos
        public string IdConsulta { get; set; }
        public string IdPaciente { get; set; }
        public string IdMedico { get; set; }
        public DateTime FechaConsulta { get; set; }
        public DateTime HoraConsulta { get; set; }
        public string EstadoConsulta { get; set; }
        #endregion

        #region Constructor

        public ConsultasMedicas(string idConsulta, string idPaciente, string idMedico, DateTime fechaConsulta, DateTime horaConsulta, string estado)
        {
            IdConsulta = idConsulta;
            IdPaciente = idPaciente;
            IdMedico = idMedico;
            FechaConsulta = fechaConsulta;
            HoraConsulta = horaConsulta;
            EstadoConsulta = estado;
        }
        #endregion



    }
}
