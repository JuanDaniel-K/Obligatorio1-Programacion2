﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class UsuariosDelSistema : Persona
    {
        #region Propiedades
        private int contador = 0;
        public int IdUsuario { get; private set; }
        public string NumeroDocumento { get; set; }
        #endregion

        #region Constructor
        public UsuariosDelSistema(string nombre, string apellido, string numeroDocumento, string nombreUsuario, string contraseña) : base(nombre, apellido, nombreUsuario, contraseña)
        {
            contador++;
            IdUsuario = contador;
            NumeroDocumento = numeroDocumento;
        }
        #endregion

        #region Metodos
        public void GestionDatosUsuarios()
        {

        }

        public void GestionDeConsultas()
        {

        }

        public void GestionPagos()
        {

        }

        public void EmitirComprobantes()
        {

        }

        public void DisponibilidadMedicos()
        {

        }
        #endregion
    }
}
