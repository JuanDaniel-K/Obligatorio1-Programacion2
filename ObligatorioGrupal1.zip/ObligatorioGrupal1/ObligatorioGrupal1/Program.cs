﻿using ObligatorioGrupal1;
using System;


// Llama la precarga antes del menú
DatosPrecargados.PrecargarDatos();

bool salir = false;
while (!salir)
{
    MostrarMenu();
    string opcion = Console.ReadLine();

    switch (opcion)
    {
        case "1":
            var adminLogueado = Login();
            if (adminLogueado == null)
                break; // Si no es admin, no entra al submenú

            bool salirSubmenu = false;
            while (!salirSubmenu)
            {
                SubmenuGUsuarios();
                string opcionSubmenu = Console.ReadLine();

                switch (opcionSubmenu)
                {
                    case "1":
                        RegistrarPaciente();
                        break;
                    case "2":
                        CambiarContraseñaAdmin(adminLogueado);
                        break;
                    case "0":
                        salirSubmenu = true;
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, intente de nuevo.");
                        break;
                }
            }
            break;
        case "2":
            SubmenuTurnos();
            {
                bool salirTurnos = false;
                while (!salirTurnos)
                {

                    string opcionTurnos = Console.ReadLine();
                    switch (opcionTurnos)
                    {
                        case "1":
                            VerDisponibilidad();
                            break;
                        case "2":
                            AgendarConsulta();
                            break;
                        case "3":
                            CancelarConsulta();
                            break;
                        case "4":
                            ReprogramarConsulta();
                            break;
                        case "5":
                            HistorialPaciente();
                            break;
                        case "0":
                            salirTurnos = true;
                            break;
                        default:
                            Console.WriteLine("Opción no válida. Por favor, intente de nuevo.");
                            break;
                    }
                }
            }
            break;

        case "3":
            SubmenuPagos();
            string opcionPagos = Console.ReadLine();

            switch (opcionPagos)
            {
                case "1":
                    break;
                case "2":
                    break;
                case "3":
                    break;
                case "0":
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, intente de nuevo.");
                    break;
            }
            break;

        case "4":
            SubmenuReportes();
            string opcionReportes = Console.ReadLine();

            switch (opcionReportes)
            {
                case "1":
                    break;
                case "2":
                    break;
                case "3":
                    break;
                case "4":
                    break;
                case "0":
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, intente de nuevo.");
                    break;
            }
            break;

        case "0":
            salir = true;
            Console.WriteLine("Gracias por usar la Clínica Vida Sana. ¡Hasta luego!");
            break;

        default:
            Console.WriteLine("Opción no válida. Por favor, intente de nuevo.");
            break;
    }
}



void MostrarMenu()
{
    Console.WriteLine("=== Bienvenido a la Clínica Vida Sana ===");
    Console.WriteLine("Seleccione una opción:");
    Console.WriteLine("1. Gestión de usuarios");
    Console.WriteLine("2. Gestión de turnos");
    Console.WriteLine("3. Pagos");
    Console.WriteLine("4. Estadísticas y reportes");
    Console.WriteLine("0. Salir");
    Console.WriteLine("==========================================");
}

void SubmenuGUsuarios()
{
    Console.WriteLine("=== Gestión de Usuarios Clínica Vida Sana ====");
    Console.WriteLine("1. Registrar nuevo paciente");
    Console.WriteLine("2. Cambio de contraseña");
    Console.WriteLine("0. Volver al menú principal");
}

void SubmenuGUsuariosPaciente()
{
    Console.WriteLine("=== Gestión de Turnos ===");
    Console.WriteLine("1. Ver disponibilidad por médico/especialidad");
    Console.WriteLine("2. Agendar consulta médica");
    Console.WriteLine("3. Cancelar consulta");
    Console.WriteLine("4. Reprogramar consulta");
    Console.WriteLine("5. Historial de consultas por paciente");
    Console.WriteLine("0. Volver al menú principal");
}
void SubmenuTurnos()
{
    Console.WriteLine("=== Gestión de Turnos ===");
    Console.WriteLine("1. Ver disponibilidad por médico/especialidad");
    Console.WriteLine("2. Agendar consulta médica");
    Console.WriteLine("3. Cancelar consulta");
    Console.WriteLine("4. Reprogramar consulta");
    Console.WriteLine("5. Historial de consultas por paciente");
    Console.WriteLine("0. Volver al menú principal");
}

void SubmenuPagos()
{
    Console.WriteLine("=== Pagos ===");
    Console.WriteLine("1. Registrar pago de consulta médica");
    Console.WriteLine("2. Emitir comprobante de pago");
    Console.WriteLine("3. Consultar pagos por paciente");
    Console.WriteLine("0. Volver al menú principal");
}

void SubmenuReportes()
{
    Console.WriteLine("=== Estadísticas y Reportes ===");
    Console.WriteLine("1. Listado de pacientes ordenados alfabéticamente");
    Console.WriteLine("2. Listado de médicos por especialidad");
    Console.WriteLine("3. Consultas más frecuentes por especialidad");
    Console.WriteLine("4. Ranking de médicos más consultados");
    Console.WriteLine("0. Volver al menú principal");
}

Administrativos Login()
{
    Console.Write("Email: ");
    string email = Console.ReadLine();
    Console.Write("Contraseña: ");
    string contraseña = Console.ReadLine();

    var admin = DatosPrecargados.listaAdministrativos.FirstOrDefault(a => a.NombreUsuario == email && a.Contraseña == contraseña);

    if (admin != null)
    {
        Console.WriteLine($"Bienvenido {admin.Nombre}");
        return admin;
    }

    Console.WriteLine("Credenciales inválidas.");
    return null;
}


void RegistrarPaciente()
{
    Console.WriteLine("=== Registro de Nuevo Paciente ===");
    Console.Write("Nombre: ");
    string nombre = Console.ReadLine();
    Console.Write("Apellido: ");
    string apellido = Console.ReadLine();
    Console.Write("Numero de Documento: ");
    int numeroDocumento = int.Parse(Console.ReadLine());
    Console.Write("Email: ");
    string email = Console.ReadLine();
    Console.Write("Nombre de usuario: ");
    string nombreUsuario = Console.ReadLine();

    // Validación
    if (DatosPrecargados.listaPacientes.Any(p => p.NumeroDocumento == numeroDocumento))
    {
        Console.WriteLine("Error: Ya existe un paciente con este Numero de Documento.");
        return;
    }
    if (DatosPrecargados.listaPacientes.Any(p => p.Email == email))
    {
        Console.WriteLine("Error: Ya existe un paciente con este email.");
        return;
    }
    if (DatosPrecargados.listaPacientes.Any(p => p.NombreUsuario == nombreUsuario))
    {
        Console.WriteLine("Error: Ya existe un paciente con este nombre de usuario.");
        return;
    }

    // Continuar registro
    Console.Write("Fecha de nacimiento (yyyy-mm-dd): ");
    DateTime fecha = DateTime.Parse(Console.ReadLine());
    Console.Write("Teléfono: ");
    int telefono = int.Parse(Console.ReadLine());
    Console.Write("Obra Social: ");
    string obraSocial = Console.ReadLine();
    Console.Write("Contraseña: ");
    string contraseña = Console.ReadLine();

    Pacientes nuevoPaciente = new Pacientes(nombre, apellido, numeroDocumento, fecha, telefono, email, obraSocial, nombreUsuario, contraseña);
    DatosPrecargados.listaPacientes.Add(nuevoPaciente);

    Console.WriteLine($"Paciente {nombre} {apellido} registrado exitosamente con ID {nuevoPaciente.IdPaciente}.");
}

void CambiarContraseñaAdministrativo()
{
    Console.WriteLine("=== Cambio de Contraseña Administrativo ===");
    Console.Write("Ingrese su nombre de usuario: ");
    string nombreUsuario = Console.ReadLine();

    var admin = DatosPrecargados.listaAdministrativos.FirstOrDefault(a => a.NombreUsuario == nombreUsuario);
    if (admin == null)
    {
        Console.WriteLine("Usuario no encontrado.");
        return;
    }

    Console.Write("Ingrese su contraseña actual: ");
    string contrasenaActual = Console.ReadLine();

    if (admin.Contraseña != contrasenaActual)
    {
        Console.WriteLine("Contraseña incorrecta.");
        return;
    }

    Console.Write("Ingrese nueva contraseña: ");
    string nuevaContrasena = Console.ReadLine();

    admin.Contraseña = nuevaContrasena;

    Console.WriteLine("Contraseña cambiada exitosamente.");
}

void CambiarContraseñaPaciente()
{
    Console.WriteLine("=== Cambio de Contraseña Paciente ===");
    Console.Write("Ingrese su nombre de usuario: ");
    string nombreUsuario = Console.ReadLine();

    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NombreUsuario == nombreUsuario);
    if (paciente == null)
    {
        Console.WriteLine("Usuario no encontrado.");
        return;
    }

    Console.Write("Ingrese su contraseña actual: ");
    string contrasenaActual = Console.ReadLine();

    if (paciente.Contraseña != contrasenaActual)
    {
        Console.WriteLine("Contraseña incorrecta.");
        return;
    }

    Console.Write("Ingrese nueva contraseña: ");
    string nuevaContrasena = Console.ReadLine();

    // Cambiar la contraseña
    paciente.Contraseña = nuevaContrasena;

    Console.WriteLine("Contraseña cambiada exitosamente.");
}

void ListarPacientes()
{
    Console.WriteLine("=== Listado de Pacientes ===");
    foreach (var p in DatosPrecargados.listaPacientes)
    {
        Console.WriteLine($"ID: {p.IdPaciente} | {p.Nombre} {p.Apellido} | Numero de Documento: {p.NumeroDocumento} | Email: {p.Email}");
    }
}


void CambiarContraseñaAdmin(Administrativos admin)
{
    Console.WriteLine("=== Cambio de Contraseña Administrativo ===");
    Console.Write("Ingrese su contraseña actual: ");
    string contrasenaActual = Console.ReadLine();

    if (admin.Contraseña != contrasenaActual)
    {
        Console.WriteLine("Contraseña incorrecta.");
        return;
    }

    Console.Write("Ingrese nueva contraseña: ");
    string nuevaContrasena = Console.ReadLine();

    admin.Contraseña = nuevaContrasena;
    Console.WriteLine("Contraseña cambiada exitosamente.");
}

void VerDisponibilidad()
{
    Console.Write("Ingrese la especialidad: ");
    string especialidad = Console.ReadLine();

    var medicos = DatosPrecargados.listaMedicos.Where(m => m.Especialidad.ToLower() == especialidad.ToLower()).ToList();
    if (!medicos.Any())
    {
        Console.WriteLine("No hay médicos con esa especialidad.");
        return;
    }

    Console.WriteLine("Disponibilidad por médico:");
    foreach (var medico in medicos)
    {
        Console.WriteLine($"Médico: {medico.Nombre} {medico.Apellido}");
        var turnosOcupados = medico.Turnos.Select(t => t.FechaHora).ToList();

        // Supongamos turnos de 9 a 17 cada hora
        for (int h = 9; h <= 17; h++)
        {
            var turno = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, h, 0, 0);
            if (!turnosOcupados.Contains(turno))
                Console.WriteLine($" - {turno:yyyy-MM-dd HH:mm}");
        }
    }
}

void AgendarConsulta()
{
    Console.Write("Ingrese DNI del paciente: ");
    int dni = int.Parse(Console.ReadLine());
    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
    if (paciente == null)
    {
        Console.WriteLine("Paciente no encontrado.");
        return;
    }

    Console.Write("Ingrese nombre del médico: ");
    string nombreMedico = Console.ReadLine();
    var medico = DatosPrecargados.listaMedicos.FirstOrDefault(m => m.Nombre.ToLower() == nombreMedico.ToLower());
    if (medico == null)
    {
        Console.WriteLine("Médico no encontrado.");
        return;
    }

    Console.Write("Ingrese fecha y hora (yyyy-MM-dd HH:mm): ");
    DateTime fechaHora = DateTime.Parse(Console.ReadLine());

    if (medico.Turnos.Any(t => t.FechaHora == fechaHora))
    {
        Console.WriteLine("El médico ya tiene un turno a esa hora.");
        return;
    }

    Turno nuevoTurno = new Turno(paciente, medico, fechaHora);
    medico.Turnos.Add(nuevoTurno);
    DatosPrecargados.listaTurnos.Add(nuevoTurno);

    Console.WriteLine("Turno agendado exitosamente.");
}

void CancelarConsulta()
{
    Console.Write("Ingrese DNI del paciente: ");
    int dni = int.Parse(Console.ReadLine());
    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
    if (paciente == null)
    {
        Console.WriteLine("Paciente no encontrado.");
        return;
    }

    Console.Write("Ingrese fecha y hora del turno a cancelar (yyyy-MM-dd HH:mm): ");
    DateTime fechaHora = DateTime.Parse(Console.ReadLine());

    var turno = DatosPrecargados.listaTurnos.FirstOrDefault(t => t.Paciente == paciente && t.FechaHora == fechaHora);
    if (turno == null)
    {
        Console.WriteLine("No se encontró el turno especificado.");
        return;
    }

    turno.Medico.Turnos.Remove(turno);
    DatosPrecargados.listaTurnos.Remove(turno);

    Console.WriteLine("Turno cancelado correctamente.");
}

void ReprogramarConsulta()
{
    Console.Write("Ingrese DNI del paciente: ");
    int dni = int.Parse(Console.ReadLine());
    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
    if (paciente == null)
    {
        Console.WriteLine("Paciente no encontrado.");
        return;
    }

    Console.Write("Ingrese fecha y hora del turno a reprogramar (yyyy-MM-dd HH:mm): ");
    DateTime fechaActual = DateTime.Parse(Console.ReadLine());

    var turno = DatosPrecargados.listaTurnos.FirstOrDefault(t => t.Paciente == paciente && t.FechaHora == fechaActual);
    if (turno == null)
    {
        Console.WriteLine("No se encontró el turno especificado.");
        return;
    }

    Console.Write("Ingrese nueva fecha y hora (yyyy-MM-dd HH:mm): ");
    DateTime nuevaFecha = DateTime.Parse(Console.ReadLine());

    if (turno.Medico.Turnos.Any(t => t.FechaHora == nuevaFecha))
    {
        Console.WriteLine("El médico ya tiene un turno a esa hora.");
        return;
    }

    turno.FechaHora = nuevaFecha;
    Console.WriteLine("Turno reprogramado correctamente.");
}

void HistorialPaciente()
{
    Console.Write("Ingrese DNI del paciente: ");
    int dni = int.Parse(Console.ReadLine());
    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
    if (paciente == null)
    {
        Console.WriteLine("Paciente no encontrado.");
        return;
    }

    var turnosPaciente = DatosPrecargados.listaTurnos
                        .Where(t => t.Paciente == paciente)
                        .OrderBy(t => t.FechaHora)
                        .ToList();

    if (!turnosPaciente.Any())
    {
        Console.WriteLine("No hay turnos registrados para este paciente.");
        return;
    }

    Console.WriteLine($"=== Historial de turnos de {paciente.Nombre} {paciente.Apellido} ===");
    foreach (var t in turnosPaciente)
    {
        Console.WriteLine($"{t.FechaHora:yyyy-MM-dd HH:mm} | Médico: {t.Medico.Nombre} {t.Medico.Apellido} | Especialidad: {t.Medico.Especialidad}");
    }
}

void RegistrarPago()
{
    Console.Write("Ingrese DNI del paciente: ");
    int dni = int.Parse(Console.ReadLine());
    var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
    if (paciente == null)
    {
        Console.WriteLine("Paciente no encontrado.");
        return;
    }

    Console.Write("Ingrese fecha y hora del turno a pagar (yyyy-MM-dd HH:mm): ");
    DateTime fechaHora = DateTime.Parse(Console.ReadLine());

    var turno = DatosPrecargados.listaTurnos.FirstOrDefault(t => t.Paciente == paciente && t.FechaHora == fechaHora);
    if (turno == null)
    {
        Console.WriteLine("No se encontró el turno.");
        return;
    }

    Console.Write("Ingrese monto del pago: ");
    double monto = double.Parse(Console.ReadLine());

    Console.Write("Ingrese método de pago (Efectivo, Tarjeta, etc.): ");
    string metodo = Console.ReadLine();

    string idPago = $"P{DatosPrecargados.listaPagos.Count + 1}";
    Pagos nuevoPago = new Pagos(idPago, turno, DateTime.Now, monto, metodo);
    DatosPrecargados.listaPagos.Add(nuevoPago);

    Console.WriteLine($"Pago registrado exitosamente con ID {idPago}.");
}

void EmitirComprobante(Pagos pago)
{
    Console.WriteLine("=== COMPROBANTE DE PAGO ===");
Console.WriteLine($"ID Pago: {pago.IdPago}");
Console.WriteLine($"Paciente: {pago.Turno.Paciente.Nombre} {pago.Turno.Paciente.Apellido}");
Console.WriteLine($"Médico: {pago.Turno.Medico.Nombre} {pago.Turno.Medico.Apellido}");
Console.WriteLine($"Fecha de Turno: {pago.Turno.FechaHora:yyyy-MM-dd HH:mm}");
Console.WriteLine($"Monto: {pago.Monto}");
Console.WriteLine($"Método de pago: {pago.MetodoPago}");
Console.WriteLine($"Fecha de Pago: {pago.FechaPago}");
Console.WriteLine("===========================");
}

void GuardarComprobanteArchivo(Pagos pago)
{
    string fileName = $"Comprobante_{pago.IdPago}.txt";
using (StreamWriter sw = new StreamWriter(fileName))
{
    sw.WriteLine("=== COMPROBANTE DE PAGO ===");
    sw.WriteLine($"ID Pago: {pago.IdPago}");
    sw.WriteLine($"Paciente: {pago.Turno.Paciente.Nombre} {pago.Turno.Paciente.Apellido}");
    sw.WriteLine($"Médico: {pago.Turno.Medico.Nombre} {pago.Turno.Medico.Apellido}");
    sw.WriteLine($"Fecha de Turno: {pago.Turno.FechaHora:yyyy-MM-dd HH:mm}");
    sw.WriteLine($"Monto: {pago.Monto}");
    sw.WriteLine($"Método de pago: {pago.MetodoPago}");
    sw.WriteLine($"Fecha de Pago: {pago.FechaPago}");
    sw.WriteLine("===========================");
}
Console.WriteLine($"Comprobante guardado en {fileName}");
}

void ConsultarPagosPorPaciente()
{
    Console.Write("Ingrese DNI del paciente: ");
int dni = int.Parse(Console.ReadLine());
var paciente = DatosPrecargados.listaPacientes.FirstOrDefault(p => p.NumeroDocumento == dni);
if (paciente == null)
{
    Console.WriteLine("Paciente no encontrado.");
    return;
}

var pagos = DatosPrecargados.listaPagos.Where(p => p.Turno.Paciente == paciente).ToList();
if (!pagos.Any())
{
    Console.WriteLine("No hay pagos registrados para este paciente.");
    return;
}

Console.WriteLine($"=== Pagos de {paciente.Nombre} {paciente.Apellido} ===");
foreach (var pago in pagos)
{
    Console.WriteLine($"ID Pago: {pago.IdPago} | Monto: {pago.Monto} | Fecha: {pago.FechaPago} | Método: {pago.MetodoPago}");
}
}