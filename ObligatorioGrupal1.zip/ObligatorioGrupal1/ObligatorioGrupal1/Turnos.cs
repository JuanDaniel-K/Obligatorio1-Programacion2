﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class Turno
    {

        public Pacientes Paciente { get; set; }
        public Medicos Medico { get; set; }
        public DateTime FechaHora { get; set; }

        public Turno(Pacientes paciente, Medicos medico, DateTime fechaHora)
        {
            Paciente = paciente;
            Medico = medico;
            FechaHora = fechaHora;
        }
    }

}
