﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class Pagos
    {
        #region Propiedades
        public string IdPago { get; set; }
        public Turno Turnos { get; set; }
        public string IdConsulta { get; set; }
        public DateTime FechaPago { get; set; }
        public double Monto { get; set; }
        public string MetodoPago { get; set; }
        #endregion

        #region Constructor
        public Pagos(string idPago, Turno turnos, string idConsulta, DateTime fechaPago, double monto, string metodoPago)
        {
            IdPago = idPago;
            Turnos = turnos;
            IdConsulta = idConsulta;
            FechaPago = fechaPago;
            Monto = monto;
            MetodoPago = metodoPago;
        }
        #endregion

    }
}
