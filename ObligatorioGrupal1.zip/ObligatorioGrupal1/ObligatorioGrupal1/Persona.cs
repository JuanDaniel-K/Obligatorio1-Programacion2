﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal abstract class Persona
    {
        #region Propiedades
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string NombreUsuario { get; set; }
        public string Contraseña { get; set; }
        #endregion

        #region Constructor
        public Persona(string nombre, string apellido, string nombreUsuario, string contraseña)
        {
            Nombre = nombre;
            Apellido = apellido;
            NombreUsuario = nombreUsuario;
            Contraseña = contraseña;
        }
        #endregion
    }
}
