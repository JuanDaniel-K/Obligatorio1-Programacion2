﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ObligatorioGrupal1
{
    internal class Administrativos : Persona
    {
        #region Propiedades
        public string IdAdministrativo { get; set; }
        #endregion

        #region Constructor
        public Administrativos(string idAdministrativo, string nombre, string apellido, string nombreUsuario, string contraseña) : base(nombre, apellido, nombreUsuario, contraseña)
        {
            IdAdministrativo = idAdministrativo;
        }
        #endregion


    }
}
