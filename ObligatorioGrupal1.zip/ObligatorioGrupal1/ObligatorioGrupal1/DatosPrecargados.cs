﻿using ObligatorioGrupal1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class DatosPrecargados
    {
        public static List<Pacientes> listaPacientes { get; set; } = new();
        public static List<Medicos> listaMedicos { get; set; } = new();
        public static List<Administrativos> listaAdministrativos { get; set; } = new();
        public static List<ConsultasMedicas> listaConsultas { get; set; } = new();
        public static List<Pagos> listaPagos { get; set; } = new();
        public static List<Turno> listaTurnos { get; set; } = new List<Turno>();


        public static void PrecargarDatos()
        {
            // --- Pacientes ---
            listaPacientes.Add(new Pacientes("Juan", "Pérez", 12345678, new DateTime(1985, 5, 20), 123456789, "juan.perez@example.com", "Obra Social 1", "juanp", "contraseña123"));
            listaPacientes.Add(new Pacientes("María", "Gómez", 87654321, new DateTime(1990, 8, 15), 987654321, "maria.gomez@example.com", "Obra Social 2", "mariag", "contraseña456"));
            listaPacientes.Add(new Pacientes("Carlos", "Ramírez", 11223344, new DateTime(1978, 3, 10), 112233445, "carlos.ramirez@example.com", "Obra Social 3", "carlosr", "clave789"));
            listaPacientes.Add(new Pacientes("Lucía", "Fernández", 55667788, new DateTime(1992, 12, 5), 556677889, "lucia.fernandez@example.com", "Obra Social 1", "luciaf", "clave101"));
            listaPacientes.Add(new Pacientes("Martín", "Santos", 99887766, new DateTime(1988, 7, 22), 998877665, "martin.santos@example.com", "Obra Social 4", "martins", "pass202"));
            listaPacientes.Add(new Pacientes("Sofía", "López", 33445566, new DateTime(1995, 2, 18), 334455667, "sofia.lopez@example.com", "Obra Social 2", "sofial", "pass303"));
            listaPacientes.Add(new Pacientes("Diego", "Martínez", 22334455, new DateTime(1982, 11, 30), 223344556, "diego.martinez@example.com", "Obra Social 3", "diegom", "clave404"));
            listaPacientes.Add(new Pacientes("Valentina", "Rodríguez", 66778899, new DateTime(1991, 6, 12), 667788990, "valentina.rodriguez@example.com", "Obra Social 1", "valentar", "pass505"));
            listaPacientes.Add(new Pacientes("Tomás", "González", 44556677, new DateTime(1986, 9, 5), 445566778, "tomas.gonzalez@example.com", "Obra Social 2", "tomasg", "clave606"));
            listaPacientes.Add(new Pacientes("Camila", "Vega", 77889900, new DateTime(1993, 4, 28), 778899001, "camila.vega@example.com", "Obra Social 3", "camilav", "pass707"));

            // --- Médicos ---
            listaMedicos.Add(new Medicos("Juan", "Pérez", "Cardiología", 1234, "Lunes y Miércoles", "9:00 - 12:00", "juanperez", "clave1"));
            listaMedicos.Add(new Medicos("María", "Gómez", "Dermatología", 2233, "Martes y Jueves", "14:00 - 18:00", "mariagomez", "clave2"));
            listaMedicos.Add(new Medicos("Carlos", "Ramírez", "Pediatría", 3344, "Lunes y Viernes", "10:00 - 13:00", "carlosram", "clave3"));
            listaMedicos.Add(new Medicos("Lucía", "Fernández", "Ginecología", 4455, "Miércoles", "15:00 - 19:00", "luciafern", "clave4"));
            listaMedicos.Add(new Medicos("Martín", "Santos", "Odontología", 5566, "Viernes", "9:00 - 12:00", "martins", "clave5"));

            // --- Administrativos ---
            listaAdministrativos.Add(new Administrativos("A1", "Ana", "Torres", "ana", "admin123"));
            listaAdministrativos.Add(new Administrativos("A2", "Pedro", "Ramírez", "pedro", "admin456"));

            // --- Consultas ---
            listaConsultas.Add(new ConsultasMedicas("C1", "1", "1", new DateTime(2025, 11, 1), new DateTime(2025, 11, 1, 9, 0, 0), "Agendada"));
            listaConsultas.Add(new ConsultasMedicas("C2", "2", "2", new DateTime(2025, 11, 2), new DateTime(2025, 11, 2, 14, 0, 0), "Agendada"));
            listaConsultas.Add(new ConsultasMedicas("C3", "3", "3", new DateTime(2025, 11, 3), new DateTime(2025, 11, 3, 10, 0, 0), "Agendada"));
            listaConsultas.Add(new ConsultasMedicas("C4", "4", "4", new DateTime(2025, 11, 4), new DateTime(2025, 11, 4, 15, 0, 0), "Agendada"));
            listaConsultas.Add(new ConsultasMedicas("C5", "5", "5", new DateTime(2025, 11, 5), new DateTime(2025, 11, 5, 9, 0, 0), "Agendada"));

            // --- Pagos ---
            listaPagos.Add(new Pagos("P1", "C1", new DateTime(2025, 10, 25), 1500.0, "Efectivo"));
            listaPagos.Add(new Pagos("P2", "C2", new DateTime(2025, 10, 26), 2000.0, "Crédito"));
        }
    }
}