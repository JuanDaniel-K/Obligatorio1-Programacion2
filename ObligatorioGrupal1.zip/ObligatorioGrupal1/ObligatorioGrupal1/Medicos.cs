﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class Medicos : Persona
    {
        #region Propiedades
        private static int contador = 0;
        public int IdMedico { get; private set; }
        public string Especialidad { get; set; }
        public int Matricula { get; set; }
        public string DiasAtencion { get; set; }
        public string HorariosDisponibles { get; set; }
        public List<Turno> Turnos { get; set; } = new List<Turno>();
        #endregion

        #region Constructor
        public Medicos(string nombre, string apellido, string especialidad, int matricula, string diasAtencion, string horariosDisponibles,  string nombreUsuario, string contraseña) : base (nombre, apellido, nombreUsuario, contraseña)
        {
            contador++;
            IdMedico = contador;
            Especialidad = especialidad;
            Matricula = matricula;
            DiasAtencion = diasAtencion;
            HorariosDisponibles = horariosDisponibles;
        }
        #endregion
    }
}
