﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatorioGrupal1
{
    internal class Pacientes : Persona
    {
        #region Propiedades
        private static int contador = 0;
        public int IdPaciente { get; private set; }
        public int NumeroDocumento { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public int Telefono { get; set; }
        public string Email { get; set; }
        public string ObraSocial { get; set; }
        #endregion

        #region Constructor
        public Pacientes(string nombre, string apellido, int numeroDocumento, DateTime fechaNacimiento, int telefono, string email, string obraSocial, string nombreUsuario, string contraseña) : base (nombre, apellido, nombreUsuario, contraseña)
        {
            contador++;
            IdPaciente = contador;
            NumeroDocumento = numeroDocumento;
            FechaNacimiento = fechaNacimiento;
            Telefono = telefono;
            Email = email;
            ObraSocial = obraSocial;
        }
        #endregion

    }
}
